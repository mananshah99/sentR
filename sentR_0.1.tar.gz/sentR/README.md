# sentR
Robust sentiment analysis using R functionality
